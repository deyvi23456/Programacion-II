﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Coppel

{
    public partial class Form1 : Form
    {
        string connectionString = "Data Source=localhost;Initial Catalog=COPPEL;Integrated Security=True";

        public Form1()
        {

            InitializeComponent();

        }
        void CargarTabla(string consulta, DataGridView grid)
        {
            SqlConnection conexion = new SqlConnection(connectionString);
            SqlDataAdapter adaptador = new SqlDataAdapter(consulta, conexion);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);
            grid.DataSource = tabla;
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            CargarTabla("SELECT * FROM Empleados", dataGridView1);
            CargarTabla("SELECT * FROM CentroTrabajo", dataGridView2);
            CargarTabla("SELECT * FROM Puesto ", dataGridView3);
            CargarTabla("SELECT * FROM Directivos", dataGridView4);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       
    }
}
